/**
 * Created by RadiusTheme on 15/11/2021.
 */
(function ($) {
    'use strict';

})(jQuery);